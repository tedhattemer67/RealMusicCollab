# Handoff: Real Music Collab — Industry visual styling

## Overview
A light-mode restyle of Real Music Collab's sign-in and core project workspace (Song → Track → Take, mix approval, notes/to-dos), built on the "Industry" design system: steel-blue accent on a light technical ground, Barlow Condensed headings over Barlow, square-cornered "blueprint" cards/buttons with corner registration marks. Muted neutral ground, one bright accent color for primary actions, generous spacing so users always know which project/song/track they're in.

## About the design files
The files in this bundle (`sign-in-directions.html`, `workspace.html`) are **design references built in HTML** — not production code to copy in. Recreate them in the existing React codebase (`packages/client`, Vite + React Router) using its current component structure and CSS approach — do not add a new CSS framework or drop these HTML files into the app directly.

## Fidelity
**High-fidelity.** Colors, type, spacing and component states below are final — implement pixel-close using the tokens in `industry.css` (included) rather than eyeballing the screenshots.

## Screens

### 1. Sign in (`sign-in-directions.html`, option `1a` — the approved direction)
Replaces `packages/client/src/pages/Login.jsx`.
- **Layout**: two-column grid on laptop, `1.05fr / .95fr`. Left: brand lockup + a plain-text feature list (Projects/Songs→Tracks→Takes/Mixes with a role annotation on the right of each row) + one line of supporting copy. Right: centered login card. Below 720px width, stack to one column (left content above the form).
- **Left column**: padding 44–56px. Kicker label "Sheet 01 · Session access" in `--color-accent-700`, 10px uppercase, 0.06em tracking, monospace. Headline "Real Music Collab" in Barlow Condensed 600, ~38–44px, line-height ~0.98, uppercase. Feature rows: 14px Barlow, each row `justify-content: space-between`, 10px vertical padding, 1px bottom border in `--color-divider`; right-hand annotation is 10px uppercase monospace at 50% text opacity.
- **Right column / login card**: a `.card.blueprint` (transparent fill, 1px hairline border, 4 corner "+" marks absolutely positioned at each corner — 11×11px cross made of two 1px bars). Max-width 380px, padding ~30px 26px, 13.6px internal gap. Contents: `<h3>Log in</h3>`, one line of muted 13px copy ("Session cookie, not a token. Refresh keeps you in."), Email field, Password field, full-width primary button (also blueprint-framed, solid accent fill, 44px tall), then a footer row with "Forgot password" link (accent color) and "Invite only" muted label right-aligned.
- **Form fields**: label 12px at 70% text opacity above each input; input is 36–44px tall, `--color-surface` background, 1px `--color-divider` border, `--radius-md` (4px), 14px text; hover darkens border, focus-visible switches border to accent with no extra outline.
- **States**: primary button hover → `--color-accent-600`; active → `--color-accent-700`; disabled → 45% opacity. Standard `:focus-visible` = 2px accent outline, 2px offset, on every interactive element.

### 2. Project workspace (`workspace.html`)
Replaces the authenticated shell in `packages/client/src/pages/Home.jsx` + `ProjectTree.jsx` (nav + tree + track list + mix panel + notes combine what's currently three separate plain pages).
- **Shell**: top nav bar (`.nav`), 3-column grid below it: `240px` song/track tree | flexible main column | `300px` notes/to-dos rail. Full app height (`min-height: 100vh`).
- **Nav bar**: brand wordmark (Barlow Condensed 600, 18px, uppercase) pinned left; "Projects" / "Band" text links (14px, accent color on hover/active); right-aligned role tag (`.tag.tag-outline`, shows "Admin") + a circular 32px avatar chip with initials, blueprint-bordered.
- **Left tree column**: "Project" label (10px muted monospace) + project name (20px condensed uppercase) at top. Below, one `.tree-song` heading per song (14px condensed uppercase) followed by its tracks as `.tree-row` items — 13px text, current-take number right-aligned in monospace; the active track row gets a 2px accent left border + `--color-accent-100` tint + `--color-accent-800` text. "+ Add track" ghost button under each song's rows. Bottom-pinned "+ New project" secondary button above a top divider.
- **Main column**: header row with "Song" label + song title (28–30px), status tag (`.tag.tag-accent`, "Draft"), "Batch upload" secondary button, "Freeze mix" primary blueprint button (all wrap on narrow widths). Below: an underline tab row (Tracks/Mixes/To-dos/Activity — 14px condensed uppercase, active tab gets a 2px accent bottom border). Track list is one `.card.blueprint` containing repeated track rows (`grid-template-columns: 1.4fr 1fr auto`): track name (16px condensed) + a striped waveform placeholder bar (34px tall, repeating diagonal/vertical accent stripes — swap for a real waveform); current-take label; History (secondary) + "+ Take" (primary) buttons. Below the track list: a "Mix approval" section — a horizontal blueprint card with mix name, status copy ("Printed from N current takes · awaiting approval"), Listen (secondary) + Approve (primary) buttons.
- **Right rail**: "To-dos" section — stacked small cards (10–13px text) each tagged with an assignee (`.tag.tag-neutral` for others, `.tag.tag-accent` for "You"). "Notes" section — inline comment list, bold author name + muted "on <target>" context line + 13px comment body.
- **Responsive**:
  - ≤900px: tree column narrows to 200px, the notes/to-dos rail hides entirely, main column padding tightens.
  - ≤640px: grid collapses to a single column, the tree sidebar hides, a sticky bottom tab bar appears (Tracks/Mixes/To-dos/Notes — 10px uppercase labels, active item in accent color) as the mobile substitute for the hidden sidebar + hidden rail, and the nav's text links hide (keep brand + avatar only).

## Interactions & behavior
- Tabs, tree rows, and the bottom tab bar are simple active/inactive state — no animation beyond the existing hover/focus rules baked into the stylesheet (color/background transitions can use the browser default, no custom easing was designed).
- Buttons/links: use the stylesheet's built-in hover/active/focus states — do not add new ones.
- No modals were designed in this pass; the DS's `.dialog`/`.dialog-backdrop` classes are available in `industry.css` if "Add track" or "+ Take" need one.

## State management
No new client state beyond what already exists (`Login.jsx`'s email/password/loading/error, session-restore in `App.jsx`). The tab row (Tracks/Mixes/To-dos/Activity) and tree selection are new UI state to add to `ProjectTree.jsx` (which track/song is selected, which tab is active) — currently that page has no such state.

## Design tokens
All tokens live in `industry.css` (copied into this folder) as CSS custom properties — use them, don't hardcode hex/px:
- `--color-bg` #f2f2f3, `--color-surface` #e9e9ea, `--color-text` #1d1f20, `--color-accent` #5980a6 (+ `--color-accent-100…900` ramp), `--color-divider`
- `--font-heading` "Barlow Condensed" (weight 600), `--font-body` "Barlow"
- `--space-1…8` (0.85× density scale), `--radius-sm/md/lg` (2/4/7px — but note this system deliberately squares off cards/buttons/inputs to `border-radius: 0` late in the sheet — see the `/* blueprint frame */` block at the bottom of the CSS)
- `--shadow-sm/md/lg`

## Assets
No real photography used. The waveform is a CSS `repeating-linear-gradient` placeholder — swap in a real per-track waveform rendering (canvas/SVG) when available. Avatar is a two-letter initial chip, not an uploaded image.

## Files in this bundle
- `sign-in-directions.html` — four explored directions; **1a is the approved one** (top-left option).
- `workspace.html` — the approved workspace screen, stacked above the sign-in screen for reference, real-viewport responsive (resize the browser to see the tablet/phone breakpoints — no separate mobile file).
- `industry.css` — the full design-system stylesheet (tokens + component classes) referenced above.
- `industry-readme.md` — the design system's own usage guide (component class reference, do's/don'ts).

## Target repo files to update
| Design screen | Repo file(s) |
| --- | --- |
| Sign in | `packages/client/src/pages/Login.jsx` |
| Invite redemption (same visual language, not separately mocked) | `packages/client/src/pages/RedeemInvite.jsx` |
| App shell / nav | `packages/client/src/pages/Home.jsx` |
| Song/Track/Take workspace | `packages/client/src/pages/ProjectTree.jsx`, `packages/client/src/components/TrackRow.jsx`, `MixPanel.jsx`, `TodosPanel.jsx`, `AnnotationsPanel.jsx` |
| Project list (not yet mocked) | `packages/client/src/pages/ProjectList.jsx` |
